#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include "evenement.h"
#include <SDL/SDL_image.h>

